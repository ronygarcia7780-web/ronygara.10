import 'dart:typed_data';

import 'package:flutter_quill/flutter_quill.dart' show Document;
import 'package:pdf/pdf.dart' show PdfColors, PdfPageFormat;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/page_settings.dart';

class PdfService {
  Future<void> export({
    required Document document,
    required PageSettings settings,
    required String title,
    Uint8List? signature,
  }) async {
    final pdf = pw.Document(title: title, theme: _theme(settings.font));
    final topNumber = settings.pageNumbers && settings.pageNumberTop;
    final bottomNumber = settings.pageNumbers && !settings.pageNumberTop;

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.fromLTRB(
          settings.marginLeft,
          settings.marginTop,
          settings.marginRight,
          settings.marginBottom,
        ),
        header: (settings.header.isEmpty && !topNumber)
            ? null
            : (ctx) => pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text(settings.header,
                        style: const pw.TextStyle(fontSize: 10)),
                    if (topNumber)
                      pw.Text('${ctx.pageNumber}',
                          style: pw.TextStyle(fontSize: settings.fontSize)),
                  ],
                ),
        footer: (settings.footer.isEmpty && !bottomNumber)
            ? null
            : (ctx) => pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text(settings.footer,
                        style: const pw.TextStyle(fontSize: 10)),
                    if (bottomNumber)
                      pw.Text('${ctx.pageNumber} / ${ctx.pagesCount}',
                          style: const pw.TextStyle(fontSize: 10)),
                  ],
                ),
        build: (_) => [
          ..._build(document, settings),
          if (signature != null) _signature(signature),
        ],
      ),
    );

    await Printing.layoutPdf(
      name: title,
      onLayout: (_) => pdf.save(),
    );
  }

  pw.ThemeData _theme(String font) {
    switch (font) {
      case 'Times New Roman':
        return pw.ThemeData.withFont(
          base: pw.Font.times(),
          bold: pw.Font.timesBold(),
          italic: pw.Font.timesItalic(),
          boldItalic: pw.Font.timesBoldItalic(),
        );
      case 'Courier':
        return pw.ThemeData.withFont(
          base: pw.Font.courier(),
          bold: pw.Font.courierBold(),
          italic: pw.Font.courierOblique(),
          boldItalic: pw.Font.courierBoldOblique(),
        );
      default:
        return pw.ThemeData.withFont(
          base: pw.Font.helvetica(),
          bold: pw.Font.helveticaBold(),
          italic: pw.Font.helveticaOblique(),
          boldItalic: pw.Font.helveticaBoldOblique(),
        );
    }
  }

  pw.Widget _signature(Uint8List bytes) {
    final img = pw.MemoryImage(bytes);
    const h = 60.0;
    final w = h * (img.width ?? 1) / (img.height ?? 1);
    return pw.Padding(
      padding: const pw.EdgeInsets.only(top: 32),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Image(img, width: w, height: h),
          pw.Container(width: 180, height: 1, color: PdfColors.black),
          pw.SizedBox(height: 4),
          pw.Text('Firma', style: const pw.TextStyle(fontSize: 10)),
        ],
      ),
    );
  }

  List<pw.Widget> _build(Document doc, PageSettings s) {
    final widgets = <pw.Widget>[];
    var spans = <pw.InlineSpan>[];
    var n = 0;

    for (final op in doc.toDelta().toList()) {
      if (!op.isInsert || op.data is! String) continue; // imágenes: pendiente
      final attrs = op.attributes ?? <String, dynamic>{};
      final parts = (op.data as String).split('\n');

      for (var i = 0; i < parts.length; i++) {
        if (parts[i].isNotEmpty) spans.add(_span(parts[i], attrs));
        if (i < parts.length - 1) {
          n = attrs['list'] == 'ordered' ? n + 1 : 0;
          widgets.add(_line(spans, attrs, s, n));
          spans = [];
        }
      }
    }

    if (widgets.isEmpty) widgets.add(pw.SizedBox());
    return widgets;
  }

  pw.InlineSpan _span(String text, Map<String, dynamic> a) {
    final u = a['underline'] == true;
    final st = a['strike'] == true;
    pw.TextDecoration? deco;
    if (u && st) {
      deco = pw.TextDecoration.combine(
        [pw.TextDecoration.underline, pw.TextDecoration.lineThrough],
      );
    } else if (u) {
      deco = pw.TextDecoration.underline;
    } else if (st) {
      deco = pw.TextDecoration.lineThrough;
    }

    return pw.TextSpan(
      text: text,
      style: pw.TextStyle(
        fontWeight: a['bold'] == true ? pw.FontWeight.bold : null,
        fontStyle: a['italic'] == true ? pw.FontStyle.italic : null,
        decoration: deco,
      ),
    );
  }

  pw.Widget _line(
    List<pw.InlineSpan> spans,
    Map<String, dynamic> a,
    PageSettings s,
    int n,
  ) {
    final h = a['header'];
    final list = a['list'];
    final base = s.fontSize;
    final size = s.apa
        ? base
        : (h == 1
            ? base * 2
            : (h == 2 ? base * 1.67 : (h == 3 ? base * 1.33 : base)));

    final align = switch (a['align']) {
      'center' => pw.TextAlign.center,
      'right' => pw.TextAlign.right,
      'justify' => pw.TextAlign.justify,
      _ => pw.TextAlign.left,
    };

    // Sangría de primera línea (solo párrafos normales), con espacios
    // no separables: el ancho de un espacio depende de la fuente.
    var content = spans;
    final plain = list == null && h == null && a['blockquote'] != true;
    if (plain && s.firstLineIndent > 0 && spans.isNotEmpty) {
      final sp = switch (s.font) {
        'Times New Roman' => 0.25,
        'Courier' => 0.6,
        _ => 0.278,
      };
      final count = (s.firstLineIndent / (s.fontSize * sp)).round();
      content = [pw.TextSpan(text: '\u00A0' * count), ...spans];
    }

    pw.Widget body = content.isEmpty
        ? pw.SizedBox(height: size * s.lineSpacing)
        : pw.RichText(
            textAlign: align,
            text: pw.TextSpan(
              children: content,
              style: pw.TextStyle(
                fontSize: size,
                height: s.lineSpacing,
                fontWeight: h != null ? pw.FontWeight.bold : null,
              ),
            ),
          );

    if (list != null) {
      final mark = list == 'ordered'
          ? "$n."
          : list == 'checked'
              ? "[x]"
              : list == 'unchecked'
                  ? "[ ]"
                  : "•";
      body = pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(
            width: 22,
            child: pw.Text(mark, style: pw.TextStyle(fontSize: size)),
          ),
          pw.Expanded(child: body),
        ],
      );
    }

    if (a['blockquote'] == true) {
      body = pw.Container(
        padding: const pw.EdgeInsets.only(left: 10),
        decoration: const pw.BoxDecoration(
          border: pw.Border(left: pw.BorderSide(width: 2)),
        ),
        child: body,
      );
    }

    return pw.Padding(
      padding: pw.EdgeInsets.only(bottom: s.apa ? 0 : 4),
      child: body,
    );
  }
}
