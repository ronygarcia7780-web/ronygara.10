import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../document.dart';
import '../models/scripta_document.dart';
import '../storage_service.dart';

class ScriptaFileService {
  Uint8List encode(ScriptaDocument d) =>
      Uint8List.fromList(utf8.encode(jsonEncode(d.toJson())));

  ScriptaDocument decode(Uint8List bytes) {
    try {
      final j = jsonDecode(utf8.decode(bytes));
      if (j is! Map<String, dynamic>) throw const FormatException();
      return ScriptaDocument.fromJson(j);
    } catch (_) {
      throw Exception('El archivo no es un documento .scripta válido.');
    }
  }

  /// Guarda en un archivo temporal y lo renombra (evita archivos a medias).
  Future<void> save(File file, ScriptaDocument d) async {
    final tmp = File('${file.path}.tmp');
    await tmp.writeAsBytes(encode(d), flush: true);
    await tmp.rename(file.path);
  }

  Future<ScriptaDocument> open(File file) async =>
      decode(await file.readAsBytes());

  /// Arma un ScriptaDocument con lo que hay guardado en scripta_docs.
  Future<ScriptaDocument> fromStorage(
      DocumentModel m, StorageService s) async {
    final content = await s.loadContent(m.id) ?? <dynamic>[];
    final obj = await s.loadObjects(m.id) ?? <String, dynamic>{};
    final sig = await s.loadSignature(m.id);
    final page = obj["page"] is Map ? obj["page"] : null;

    return ScriptaDocument.fromJson({
      "format": "scripta",
      "id": m.id,
      "title": m.title,
      "content": content,
      "folderId": m.folderId,
      "page": page,
      "textBoxes": obj["textBoxes"],
      "shapes": obj["shapes"],
      "signature": sig == null ? null : base64Encode(sig),
      "created": m.updated.toIso8601String(),
      "updated": m.updated.toIso8601String(),
    });
  }

  /// Importa como documento NUEVO (id nuevo, no pisa nada). Devuelve el modelo.
  Future<DocumentModel> importInto(ScriptaDocument d, StorageService s) async {
    final m = DocumentModel.create(d.title);
    await s.saveContent(m.id, d.content);
    await s.saveObjects(m.id, {
      "textBoxes": d.textBoxes.map((e) => e.toJson()).toList(),
      "shapes": d.shapes.map((e) => e.toJson()).toList(),
      "page": d.page.toJson(),
    });
    if (d.signature != null) {
      await s.saveSignature(m.id, base64Decode(d.signature!));
    }
    final docs = await s.load();
    docs.insert(0, m);
    await s.save(docs);
    return m;
  }
}
