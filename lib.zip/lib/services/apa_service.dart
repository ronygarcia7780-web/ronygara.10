import '../models/page_settings.dart';

class APAService {
  static const font = "Times New Roman";
  static const fontSize = 12.0;
  static const spacing = 2.0;
  static const margin = 72.0; // 1 pulgada
  static const indent = 36.0; // 0.5 pulgada

  /// Modifica la configuración de página para cumplir APA 7.
  void apply(PageSettings s) {
    s.font = font;
    s.fontSize = fontSize;
    s.lineSpacing = spacing;
    s.marginTop = margin;
    s.marginBottom = margin;
    s.marginLeft = margin;
    s.marginRight = margin;
    s.firstLineIndent = indent;
    s.pageNumbers = true;
    s.pageNumberTop = true;
    s.apa = true;
  }
}
