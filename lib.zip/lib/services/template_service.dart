// SIN USO. Solo devuelve mapas; falta aplicarlos (APA ya está en apa_service.dart).
class TemplateService {
  Map<String, dynamic> apa7() {
    return {
      "font": "Times New Roman",
      "size": 12,
      "spacing": 2.0,
      "margin": 72,
    };
  }

  Map<String, dynamic> informe() {
    return {
      "font": "Arial",
      "size": 12,
      "spacing": 1.5,
    };
  }

  Map<String, dynamic> curriculum() {
    return {
      "font": "Calibri",
      "size": 11,
      "spacing": 1.15,
    };
  }
}
