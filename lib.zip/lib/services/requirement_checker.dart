import '../models/page_settings.dart';

class RequirementChecker {
  static bool _eq(double a, double b) => (a - b).abs() < 0.01;

  /// Devuelve la lista de incumplimientos; vacía si todo está bien.
  static List<String> checkApa(
    PageSettings s, {
    int words = 0,
    int minWords = 0, // opcional: 0 = no revisar
  }) {
    final r = <String>[];

    if (s.font != 'Times New Roman') {
      r.add('Fuente: debe ser Times New Roman (ahora: ${s.font}).');
    }
    if (!_eq(s.fontSize, 12)) {
      r.add('Tamaño de letra: debe ser 12 pt (ahora: ${s.fontSize.round()}).');
    }
    if (!_eq(s.lineSpacing, 2.0)) {
      r.add('Interlineado: debe ser 2.0 (ahora: ${s.lineSpacing.toStringAsFixed(2)}).');
    }
    final margins = [s.marginTop, s.marginBottom, s.marginLeft, s.marginRight];
    if (!margins.every((m) => _eq(m, 72))) {
      r.add('Márgenes: deben ser 72 pt (2.54 cm) en los cuatro lados.');
    }
    if (!_eq(s.firstLineIndent, 36)) {
      r.add('Sangría: la primera línea de cada párrafo debe medir 0.5 in (36 pt).');
    }
    if (!s.pageNumbers || !s.pageNumberTop) {
      r.add('Numeración: el número de página va arriba a la derecha.');
    }
    if (minWords > 0 && words < minWords) {
      r.add('Extensión: tiene $words palabras y se piden al menos $minWords.');
    }
    return r;
  }
}
