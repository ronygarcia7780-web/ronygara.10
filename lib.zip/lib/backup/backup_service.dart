import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';

import '../storage_service.dart';

class BackupService {
  final StorageService storage;
  BackupService(this.storage);

  // Solo nombres planos .json / .png (evita rutas maliciosas dentro del zip).
  static final _valid = RegExp(r'^[A-Za-z0-9_\-]+\.(json|png)$');

  /// Comprime todos los documentos en un .zip (en memoria).
  Future<Uint8List> create() async {
    final d = await storage.dir();
    final archive = Archive();
    await for (final e in d.list()) {
      if (e is! File) continue;
      final name = e.uri.pathSegments.last;
      if (name == 'search_index.json' || !_valid.hasMatch(name)) continue;
      final bytes = await e.readAsBytes();
      archive.addFile(ArchiveFile(name, bytes.length, bytes));
    }
    final out = ZipEncoder().encode(archive);
    return Uint8List.fromList(out as List<int>);
  }

  /// Valida el zip ANTES de borrar nada. Devuelve cuántos archivos restauró.
  Future<int> restore(Uint8List bytes) async {
    final Archive archive;
    try {
      archive = ZipDecoder().decodeBytes(bytes);
    } catch (_) {
      throw Exception('El archivo no es un zip válido.');
    }

    final files = <String, List<int>>{};
    for (final f in archive.files) {
      if (!f.isFile) continue;
      final name = f.name;
      if (!_valid.hasMatch(name) || name == 'search_index.json') continue;
      files[name] = List<int>.from(f.content as List<int>);
    }

    final idx = files['index.json'];
    if (idx == null) {
      throw Exception('No es un respaldo de Scripta (falta index.json).');
    }
    dynamic parsed;
    try {
      parsed = jsonDecode(utf8.decode(idx));
    } catch (_) {}
    if (parsed is! List) {
      throw Exception('El índice del respaldo está dañado.');
    }

    // Todo válido: ahora sí reemplazar.
    final d = await storage.dir();
    await for (final e in d.list()) {
      if (e is File) await e.delete();
    }
    for (final en in files.entries) {
      await File('${d.path}/${en.key}').writeAsBytes(en.value);
    }
    return files.length;
  }
}
