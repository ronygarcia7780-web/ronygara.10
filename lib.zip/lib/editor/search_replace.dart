// SIN USO por ahora. Hay que rehacerlo sobre Quill (buscar dentro del documento).
String replaceText(String original, String search, String replace) {
  return original.replaceAll(search, replace);
}
