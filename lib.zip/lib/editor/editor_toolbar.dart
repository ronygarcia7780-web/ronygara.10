import 'package:flutter/material.dart';

class BottomEditorToolbar extends StatelessWidget {
  final VoidCallback onImage;
  final VoidCallback onTable;
  final VoidCallback onSearch;
  final VoidCallback onTextBox;
  final VoidCallback onShape;

  const BottomEditorToolbar({
    super.key,
    required this.onImage,
    required this.onTable,
    required this.onSearch,
    required this.onTextBox,
    required this.onShape,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(onPressed: onImage, icon: const Icon(Icons.image)),
          IconButton(onPressed: onTable, icon: const Icon(Icons.table_chart)),
          IconButton(onPressed: onTextBox, icon: const Icon(Icons.text_fields)),
          IconButton(onPressed: onShape, icon: const Icon(Icons.category)),
          IconButton(onPressed: onSearch, icon: const Icon(Icons.search)),
        ],
      ),
    );
  }
}
