import 'dart:async';

class AutoSaveService {
  Timer? _timer;

  void start(void Function() save) {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => save());
  }

  void stop() => _timer?.cancel();
}
