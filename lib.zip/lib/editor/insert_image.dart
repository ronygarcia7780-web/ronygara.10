import 'package:image_picker/image_picker.dart';

class InsertImageService {
  final picker = ImagePicker();

  Future<XFile?> pickImage() async {
    return await picker.pickImage(source: ImageSource.gallery);
  }
}
