import 'package:flutter/material.dart';
import '../models/table_model.dart';

class TableWidget extends StatelessWidget {
  final TableModel table;
  final VoidCallback? onChanged;

  const TableWidget({super.key, required this.table, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Table(
      border: TableBorder.all(),
      children: List.generate(
        table.rows,
        (r) => TableRow(
          children: List.generate(
            table.columns,
            (c) => Padding(
              padding: const EdgeInsets.all(6),
              child: TextFormField(
                initialValue: table.cells[r][c],
                decoration: const InputDecoration(border: InputBorder.none),
                onChanged: (v) {
                  table.cells[r][c] = v;
                  onChanged?.call();
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
