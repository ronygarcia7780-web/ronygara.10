import 'package:flutter/material.dart';
import '../models/shape_model.dart';
import '../models/text_box_model.dart';
import 'draggable_text_box.dart';
import 'shape_canvas.dart';

class ObjectLayer extends StatelessWidget {
  final List<TextBoxModel> textBoxes;
  final List<ShapeModel> shapes;
  final VoidCallback onChanged;
  final void Function(TextBoxModel) onDeleteTextBox;

  const ObjectLayer({
    super.key,
    required this.textBoxes,
    required this.shapes,
    required this.onChanged,
    required this.onDeleteTextBox,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: ShapeCanvas(shapes: shapes)),
        ...textBoxes.map(
          (e) => DraggableTextBox(
            key: ObjectKey(e),
            model: e,
            onChanged: onChanged,
            onDelete: () => onDeleteTextBox(e),
          ),
        ),
      ],
    );
  }
}
