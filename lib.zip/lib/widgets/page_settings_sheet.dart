import 'package:flutter/material.dart';
import '../models/page_settings.dart';

/// Devuelve true si el usuario guardó cambios.
Future<bool> showPageSettingsSheet(
  BuildContext context,
  PageSettings s,
) async {
  final header = TextEditingController(text: s.header);
  final footer = TextEditingController(text: s.footer);
  var numbers = s.pageNumbers;
  var numberTop = s.pageNumberTop;
  var margin = s.marginTop;
  var spacing = s.lineSpacing;
  var font = s.font;
  var size = s.fontSize;
  var indent = s.firstLineIndent > 0;
  var apa = s.apa;

  final saved = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          16,
          16,
          MediaQuery.of(ctx).viewInsets.bottom + 16,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Configurar página",
                style: Theme.of(ctx).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: header,
                decoration: const InputDecoration(labelText: "Encabezado"),
              ),
              TextField(
                controller: footer,
                decoration: const InputDecoration(labelText: "Pie de página"),
              ),
              const SizedBox(height: 8),
              const Text("Fuente (se aplica al PDF)"),
              DropdownButton<String>(
                isExpanded: true,
                value: font,
                items: PageSettings.fonts
                    .map((f) => DropdownMenuItem(value: f, child: Text(f)))
                    .toList(),
                onChanged: (v) => set(() => font = v ?? font),
              ),
              Text("Tamaño de letra: ${size.round()} pt"),
              Slider(
                value: size,
                min: 10,
                max: 16,
                divisions: 6,
                onChanged: (v) => set(() => size = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text("Numerar páginas"),
                value: numbers,
                onChanged: (v) => set(() => numbers = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text("Número arriba a la derecha"),
                value: numberTop,
                onChanged: (v) => set(() => numberTop = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text("Sangría en la primera línea (0.5 in)"),
                value: indent,
                onChanged: (v) => set(() => indent = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text("Estilo APA (títulos del mismo tamaño)"),
                value: apa,
                onChanged: (v) => set(() => apa = v),
              ),
              Text("Márgenes: ${margin.round()} pt"),
              Slider(
                value: margin,
                min: 36,
                max: 108,
                divisions: 8,
                onChanged: (v) => set(() => margin = v),
              ),
              Text("Interlineado: ${spacing.toStringAsFixed(2)}"),
              Slider(
                value: spacing,
                min: 1,
                max: 2,
                divisions: 20,
                onChanged: (v) => set(() => spacing = v),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text("Guardar"),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );

  if (saved != true) return false;

  s.header = header.text;
  s.footer = footer.text;
  s.pageNumbers = numbers;
  s.pageNumberTop = numberTop;
  s.font = font;
  s.fontSize = size.roundToDouble();
  s.firstLineIndent = indent ? 36 : 0;
  s.apa = apa;
  s.marginTop = margin;
  s.marginBottom = margin;
  s.marginLeft = margin;
  s.marginRight = margin;
  s.lineSpacing = (spacing * 20).round() / 20;
  return true;
}
