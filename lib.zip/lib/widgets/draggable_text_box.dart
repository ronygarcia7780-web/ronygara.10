import 'package:flutter/material.dart';
import '../models/text_box_model.dart';

class DraggableTextBox extends StatefulWidget {
  final TextBoxModel model;
  final VoidCallback onChanged;
  final VoidCallback onDelete;

  const DraggableTextBox({
    super.key,
    required this.model,
    required this.onChanged,
    required this.onDelete,
  });

  @override
  State<DraggableTextBox> createState() => _DraggableTextBoxState();
}

class _DraggableTextBoxState extends State<DraggableTextBox> {
  late Offset position;
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    position = widget.model.position;
    _c = TextEditingController(text: widget.model.text);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;

    return Positioned(
      left: position.dx,
      top: position.dy,
      child: Container(
        width: widget.model.size.width,
        height: widget.model.size.height,
        decoration: BoxDecoration(
          color: color.surface,
          border: Border.all(color: color.primary),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            GestureDetector(
              onPanUpdate: (d) {
                setState(() {
                  position += d.delta;
                  widget.model.position = position;
                });
                widget.onChanged();
              },
              child: Container(
                height: 28,
                decoration: BoxDecoration(
                  color: color.primaryContainer,
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(9)),
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 6),
                    const Icon(Icons.drag_indicator, size: 18),
                    const Spacer(),
                    InkWell(
                      onTap: widget.onDelete,
                      child: const Padding(
                        padding: EdgeInsets.all(4),
                        child: Icon(Icons.close, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: TextField(
                  controller: _c,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    hintText: "Escribe aquí",
                  ),
                  onChanged: (v) {
                    widget.model.text = v;
                    widget.onChanged();
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
