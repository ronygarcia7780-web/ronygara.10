// SIN USO. Falta conectarlo al editor y a comment_service.
import 'package:flutter/material.dart';
import '../models/comment_model.dart';

class CommentsPanel extends StatelessWidget {
  final List<CommentModel> comments;

  const CommentsPanel({
    super.key,
    required this.comments,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: comments.length,
      itemBuilder: (_, i) {
        final c = comments[i];

        return ListTile(
          leading: const Icon(Icons.comment),
          title: Text(c.author),
          subtitle: Text(c.text),
        );
      },
    );
  }
}
