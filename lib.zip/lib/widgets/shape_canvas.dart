import 'package:flutter/material.dart';
import '../models/shape_model.dart';

class ShapeCanvas extends StatelessWidget {
  final List<ShapeModel> shapes;

  const ShapeCanvas({super.key, required this.shapes});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: CustomPaint(
        painter: ShapePainter(shapes),
        size: Size.infinite,
      ),
    );
  }
}

class ShapePainter extends CustomPainter {
  final List<ShapeModel> shapes;

  ShapePainter(this.shapes);

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in shapes) {
      final paint = Paint()
        ..color = s.color
        ..strokeWidth = 3
        ..style = PaintingStyle.stroke;

      final rect = Rect.fromLTWH(
        s.position.dx,
        s.position.dy,
        s.size.width,
        s.size.height,
      );

      switch (s.type) {
        case ShapeType.rectangle:
          canvas.drawRect(rect, paint);
        case ShapeType.circle:
          canvas.drawOval(rect, paint);
        case ShapeType.line:
          canvas.drawLine(rect.topLeft, rect.bottomRight, paint);
      }
    }
  }

  @override
  bool shouldRepaint(ShapePainter old) => true;
}
