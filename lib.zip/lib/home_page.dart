import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import 'backup/backup_service.dart';
import 'document.dart';
import 'editor_page.dart';
import 'folders/folder_dialogs.dart';
import 'models/folder_model.dart';
import 'search/search_page.dart';
import 'security/auth_service.dart';
import 'storage_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final storage = StorageService();
  late final BackupService _backup = BackupService(storage);
  final _auth = AuthService();

  List<DocumentModel> docs = [];
  List<FolderModel> folders = [];
  String _filter = 'all'; // 'all' | '' (sin carpeta) | id de carpeta
  bool _lockOn = false;

  @override
  void initState() {
    super.initState();
    loadDocs();
    _auth.isEnabled().then((v) {
      if (mounted) setState(() => _lockOn = v);
    });
  }

  Future<void> loadDocs() async {
    docs = await storage.load();
    folders = await storage.loadFolders();
    if (_filter != 'all' &&
        _filter != '' &&
        !folders.any((f) => f.id == _filter)) {
      _filter = 'all';
    }
    if (!mounted) return;
    setState(() {});
  }

  void _msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  // ---------- Documentos ----------
  Future<void> newDoc() async {
    final folderId = (_filter == 'all' || _filter == '') ? null : _filter;
    final doc = DocumentModel.create(
      "Documento ${docs.length + 1}",
      folderId: folderId,
    );
    docs.insert(0, doc);
    await storage.save(docs);
    if (!mounted) return;
    await _open(doc);
  }

  Future<void> _open(DocumentModel d) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EditorPage(doc: d, storage: storage),
      ),
    );
    loadDocs();
  }

  Future<void> _rename(DocumentModel d) async {
    final t = await askText(context, 'Renombrar', initial: d.title);
    if (t == null) return;
    d.title = t;
    await storage.save(docs);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _move(DocumentModel d) async {
    final id = await pickFolder(context, folders);
    if (id == null) return;
    d.folderId = id.isEmpty ? null : id;
    await storage.save(docs);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _delete(DocumentModel d) async {
    final ok = await confirm(
      context,
      'Eliminar documento',
      '"${d.title}" se eliminará para siempre.',
    );
    if (!ok) return;
    docs.remove(d);
    await storage.save(docs);
    await storage.deleteFiles(d.id);
    if (!mounted) return;
    setState(() {});
  }

  void _docMenu(DocumentModel d) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Renombrar'),
              onTap: () {
                Navigator.pop(ctx);
                _rename(d);
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder),
              title: const Text('Mover a carpeta'),
              onTap: () {
                Navigator.pop(ctx);
                _move(d);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Eliminar'),
              onTap: () {
                Navigator.pop(ctx);
                _delete(d);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ---------- Carpetas ----------
  Future<void> _createFolder() async {
    final f = await askFolder(context);
    if (f == null) return;
    folders.add(f);
    await storage.saveFolders(folders);
    if (!mounted) return;
    setState(() => _filter = f.id);
  }

  Future<void> _editFolder(FolderModel f) async {
    final r = await askFolder(context, current: f);
    if (r == null) return;
    f.name = r.name;
    f.color = r.color;
    await storage.saveFolders(folders);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _deleteFolder(FolderModel f) async {
    final ok = await confirm(
      context,
      'Eliminar carpeta',
      'Los documentos de "${f.name}" NO se borran; pasan a "Sin carpeta".',
    );
    if (!ok) return;
    for (final d in docs) {
      if (d.folderId == f.id) d.folderId = null;
    }
    folders.remove(f);
    await storage.save(docs);
    await storage.saveFolders(folders);
    if (!mounted) return;
    setState(() {
      if (_filter == f.id) _filter = 'all';
    });
  }

  void _folderMenu(FolderModel f) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Editar carpeta'),
              onTap: () {
                Navigator.pop(ctx);
                _editFolder(f);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Eliminar carpeta'),
              onTap: () {
                Navigator.pop(ctx);
                _deleteFolder(f);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ---------- Respaldo ----------
  Future<void> _createBackup() async {
    try {
      final bytes = await _backup.create();
      final n = DateTime.now();
      String t(int v) => v.toString().padLeft(2, '0');
      final stamp = "${n.year}${t(n.month)}${t(n.day)}_${t(n.hour)}${t(n.minute)}";
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Guardar respaldo',
        fileName: 'scripta_respaldo_$stamp.zip',
        type: FileType.custom,
        allowedExtensions: ['zip'],
        bytes: bytes,
      );
      _msg(path == null
          ? 'Respaldo cancelado o no se pudo guardar.'
          : 'Respaldo guardado.');
    } catch (e) {
      _msg('No se pudo crear el respaldo: $e');
    }
  }

  Future<void> _restoreBackup() async {
    final ok = await confirm(
      context,
      'Restaurar respaldo',
      'Se REEMPLAZARÁN todos tus documentos actuales por los del respaldo. '
          'Te recomiendo crear un respaldo antes.',
    );
    if (!ok) return;
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip'],
        withData: true,
      );
      final bytes = res?.files.single.bytes;
      if (bytes == null) return;
      final n = await _backup.restore(bytes);
      await loadDocs();
      _msg('Respaldo restaurado ($n archivos).');
    } catch (e) {
      _msg('No se pudo restaurar: ${e.toString().replaceFirst('Exception: ', '')}');
    }
  }

  // ---------- Bloqueo ----------
  Future<void> _toggleLock() async {
    if (_lockOn) {
      if (await _auth.unlock()) {
        await _auth.setEnabled(false);
        if (mounted) setState(() => _lockOn = false);
      }
      return;
    }
    if (!await _auth.isAvailable()) {
      _msg('Tu teléfono no tiene huella, PIN o patrón configurado.');
      return;
    }
    if (await _auth.unlock()) {
      await _auth.setEnabled(true);
      if (mounted) setState(() => _lockOn = true);
      _msg('Bloqueo activado. Bloquea la app, pero no cifra los archivos.');
    }
  }

  // ---------- UI ----------
  String fmt(DateTime d) {
    String t(int n) => n.toString().padLeft(2, '0');
    return "${t(d.day)}/${t(d.month)}/${d.year} ${t(d.hour)}:${t(d.minute)}";
  }

  FolderModel? _folderOf(String? id) {
    if (id == null) return null;
    for (final f in folders) {
      if (f.id == id) return f;
    }
    return null;
  }

  Widget _chips() {
    Widget chip(String label, String value, {Color? dot, FolderModel? f}) {
      final c = ChoiceChip(
        avatar: dot == null ? null : CircleAvatar(backgroundColor: dot, radius: 6),
        label: Text(label),
        selected: _filter == value,
        onSelected: (_) => setState(() => _filter = value),
      );
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: f == null
            ? c
            : GestureDetector(onLongPress: () => _folderMenu(f), child: c),
      );
    }

    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          chip('Todos', 'all'),
          chip('Sin carpeta', ''),
          for (final f in folders) chip(f.name, f.id, dot: Color(f.color), f: f),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = docs.where((d) {
      if (_filter == 'all') return true;
      if (_filter == '') return d.folderId == null;
      return d.folderId == _filter;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Scripta"),
        actions: [
          IconButton(
            tooltip: 'Buscar',
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SearchPage(
                  storage: storage,
                  docs: docs,
                  folders: folders,
                  onOpen: _open,
                ),
              ),
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              switch (v) {
                case 'folder':
                  _createFolder();
                case 'backup':
                  _createBackup();
                case 'restore':
                  _restoreBackup();
                case 'lock':
                  _toggleLock();
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'folder', child: Text('Nueva carpeta')),
              const PopupMenuItem(value: 'backup', child: Text('Crear respaldo')),
              const PopupMenuItem(value: 'restore', child: Text('Restaurar respaldo')),
              CheckedPopupMenuItem(
                value: 'lock',
                checked: _lockOn,
                child: const Text('Bloqueo con huella / PIN'),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: newDoc,
        icon: const Icon(Icons.add),
        label: const Text("Nuevo"),
      ),
      body: Column(
        children: [
          _chips(),
          Expanded(
            child: visible.isEmpty
                ? const Center(child: Text("No hay documentos"))
                : ListView.builder(
                    itemCount: visible.length,
                    itemBuilder: (_, i) {
                      final d = visible[i];
                      final f = _folderOf(d.folderId);
                      return ListTile(
                        leading: Icon(
                          Icons.description,
                          color: f == null ? null : Color(f.color),
                        ),
                        title: Text(d.title),
                        subtitle: Text(
                          f == null ? fmt(d.updated) : "${fmt(d.updated)} · ${f.name}",
                        ),
                        onTap: () => _open(d),
                        onLongPress: () => _docMenu(d),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
