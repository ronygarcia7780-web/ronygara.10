import 'dart:math' as math;

import 'package:flutter_quill/flutter_quill.dart' show Document;

import '../document.dart';
import '../storage_service.dart';

/// Minúsculas y sin acentos. Conserva la longitud del texto
/// (así las posiciones sirven para recortar el fragmento).
String normalize(String s) {
  const from = 'áàäâãéèëêíìïîóòöôõúùüûñç';
  const to = 'aaaaaeeeeiiiiooooouuuunc';
  final b = StringBuffer();
  for (final r in s.toLowerCase().runes) {
    final ch = String.fromCharCode(r);
    final i = from.indexOf(ch);
    b.write(i == -1 ? ch : to[i]);
  }
  return b.toString();
}

class SearchResult {
  final DocumentModel doc;
  final String snippet;
  SearchResult(this.doc, this.snippet);
}

class SearchService {
  final StorageService storage;
  SearchService(this.storage);

  Map<String, dynamic> _index = {};
  final Map<String, String> _norm = {};

  /// Actualiza el índice SOLO de los documentos nuevos o cambiados
  /// (compara la fecha de modificación) y quita los eliminados.
  Future<void> refresh(List<DocumentModel> docs) async {
    _index = await storage.loadSearchIndex();
    var changed = false;
    final ids = docs.map((d) => d.id).toSet();

    _index.removeWhere((k, _) {
      final gone = !ids.contains(k);
      if (gone) changed = true;
      return gone;
    });

    for (final d in docs) {
      final e = _index[d.id];
      final stamp = d.updated.toIso8601String();
      if (e is Map && e['u'] == stamp) continue;

      final delta = await storage.loadContent(d.id);
      var text = '';
      if (delta != null && delta.isNotEmpty) {
        try {
          text = Document.fromJson(delta).toPlainText();
        } catch (_) {}
      }
      _index[d.id] = {'u': stamp, 't': text};
      changed = true;
    }

    if (changed) await storage.saveSearchIndex(_index);
    _norm.clear();
  }

  String _text(String id) {
    final e = _index[id];
    return e is Map ? (e['t'] as String? ?? '') : '';
  }

  List<String> _terms(String q) {
    final out = <String>[];
    final rest = q.replaceAllMapped(RegExp(r'"([^"]+)"'), (m) {
      out.add(normalize(m[1]!.trim()));
      return ' ';
    });
    for (final w in rest.split(RegExp(r'\s+'))) {
      final t = normalize(w.replaceAll('"', '').trim());
      if (t.isNotEmpty) out.add(t);
    }
    return out.where((t) => t.isNotEmpty).toList();
  }

  /// folderId: null = todas, '' = sin carpeta, otro = esa carpeta.
  /// Frases entre comillas se buscan completas; todas las palabras deben aparecer.
  List<SearchResult> search(
    List<DocumentModel> docs, {
    String query = '',
    String? folderId,
    DateTime? from,
    DateTime? to,
  }) {
    final terms = _terms(query);
    if (terms.isEmpty && folderId == null && from == null && to == null) {
      return [];
    }

    final start = from == null ? null : DateTime(from.year, from.month, from.day);
    final end = to == null
        ? null
        : DateTime(to.year, to.month, to.day).add(const Duration(days: 1));

    final out = <SearchResult>[];
    for (final d in docs) {
      if (folderId != null) {
        if (folderId == '' ? d.folderId != null : d.folderId != folderId) {
          continue;
        }
      }
      if (start != null && d.updated.isBefore(start)) continue;
      if (end != null && !d.updated.isBefore(end)) continue;

      var snippet = '';
      if (terms.isNotEmpty) {
        final full = '${d.title}\n${_text(d.id)}';
        final n = _norm.putIfAbsent(d.id, () => normalize(full));
        if (!terms.every(n.contains)) continue;

        final i = n.indexOf(terms.first);
        final s = math.max(0, i - 30);
        final e = math.min(full.length, i + terms.first.length + 60);
        if (s < e) {
          snippet = '${s > 0 ? '…' : ''}'
              '${full.substring(s, e).replaceAll('\n', ' ')}'
              '${e < full.length ? '…' : ''}';
        }
      }
      out.add(SearchResult(d, snippet));
    }
    return out;
  }
}
