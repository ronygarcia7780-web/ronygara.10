import 'package:flutter/material.dart';

import '../document.dart';
import '../models/folder_model.dart';
import '../storage_service.dart';
import 'search_service.dart';

class SearchPage extends StatefulWidget {
  final StorageService storage;
  final List<DocumentModel> docs;
  final List<FolderModel> folders;
  final void Function(DocumentModel) onOpen;

  const SearchPage({
    super.key,
    required this.storage,
    required this.docs,
    required this.folders,
    required this.onOpen,
  });

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  late final SearchService _service = SearchService(widget.storage);
  final _q = TextEditingController();

  bool _ready = false;
  String _folder = 'all'; // 'all' | '' | id
  DateTime? _from;
  DateTime? _to;
  List<SearchResult> _results = [];

  @override
  void initState() {
    super.initState();
    _service.refresh(widget.docs).then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      _run();
    });
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _run() {
    if (!_ready) return;
    setState(() {
      _results = _service.search(
        widget.docs,
        query: _q.text,
        folderId: _folder == 'all' ? null : _folder,
        from: _from,
        to: _to,
      );
    });
  }

  Future<void> _pickRange() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (r == null) return;
    _from = r.start;
    _to = r.end;
    _run();
  }

  String _d(DateTime d) =>
      "${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}";

  @override
  Widget build(BuildContext context) {
    final hasFilter = _q.text.trim().isNotEmpty ||
        _folder != 'all' ||
        _from != null;

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _q,
          autofocus: true,
          onChanged: (_) => _run(),
          decoration: const InputDecoration(
            hintText: 'Palabras o "frase exacta"',
            border: InputBorder.none,
          ),
        ),
      ),
      body: Column(
        children: [
          if (!_ready) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: _folder,
                    items: [
                      const DropdownMenuItem(
                          value: 'all', child: Text('Todas las carpetas')),
                      const DropdownMenuItem(
                          value: '', child: Text('Sin carpeta')),
                      for (final f in widget.folders)
                        DropdownMenuItem(value: f.id, child: Text(f.name)),
                    ],
                    onChanged: (v) {
                      _folder = v ?? 'all';
                      _run();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: _pickRange,
                  icon: const Icon(Icons.date_range, size: 18),
                  label: Text(_from == null
                      ? 'Fechas'
                      : '${_d(_from!)} – ${_d(_to!)}'),
                ),
                if (_from != null)
                  IconButton(
                    tooltip: 'Quitar fechas',
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      _from = null;
                      _to = null;
                      _run();
                    },
                  ),
              ],
            ),
          ),
          Expanded(
            child: !hasFilter
                ? const Center(child: Text('Escribe para buscar'))
                : _results.isEmpty
                    ? const Center(child: Text('Sin resultados'))
                    : ListView.builder(
                        itemCount: _results.length,
                        itemBuilder: (_, i) {
                          final r = _results[i];
                          return ListTile(
                            leading: const Icon(Icons.description),
                            title: Text(r.doc.title),
                            subtitle: r.snippet.isEmpty
                                ? Text(_d(r.doc.updated))
                                : Text(r.snippet,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis),
                            onTap: () {
                              Navigator.pop(context);
                              widget.onOpen(r.doc);
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
