import 'package:flutter/material.dart';
import 'auth_service.dart';

/// Cubre TODA la app (incluidas las pantallas abiertas) con una pantalla
/// de bloqueo. Se pide al abrir y al volver tras más de 20 s en segundo plano
/// (el margen evita re-pedir al usar el selector de archivos o compartir).
class LockGate extends StatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});

  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  static const _grace = Duration(seconds: 20);

  final _auth = AuthService();
  bool _locked = true;
  bool _ready = false;
  bool _busy = false;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _open() {
    if (!mounted) return;
    setState(() {
      _ready = true;
      _locked = false;
    });
  }

  Future<void> _start() async {
    final enabled = await _auth.isEnabled();
    if (!enabled) {
      _open();
      return;
    }
    // Si el teléfono ya no tiene bloqueo, no dejar al usuario fuera.
    if (!await _auth.isAvailable()) {
      await _auth.setEnabled(false);
      _open();
      return;
    }
    if (mounted) setState(() => _ready = true);
    await _unlock();
  }

  Future<void> _unlock() async {
    if (_busy) return;
    _busy = true;
    final ok = await _auth.unlock();
    _busy = false;
    if (ok && mounted) setState(() => _locked = false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt ??= DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      _onResume();
    }
  }

  Future<void> _onResume() async {
    final at = _pausedAt;
    _pausedAt = null;
    if (!_ready || _busy || at == null) return;
    if (DateTime.now().difference(at) < _grace) return;
    if (!await _auth.isEnabled()) return;
    if (!mounted) return;
    setState(() => _locked = true);
    _unlock();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        if (_locked)
          Positioned.fill(
            child: _LockScreen(ready: _ready, onUnlock: _unlock),
          ),
      ],
    );
  }
}

class _LockScreen extends StatelessWidget {
  final bool ready;
  final VoidCallback onUnlock;

  const _LockScreen({required this.ready, required this.onUnlock});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock, size: 64),
            const SizedBox(height: 16),
            Text(
              'Scripta está bloqueada',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 24),
            if (ready)
              FilledButton.icon(
                onPressed: onUnlock,
                icon: const Icon(Icons.fingerprint),
                label: const Text('Desbloquear'),
              )
            else
              const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}
