class CommentModel {
  String id;
  String author;
  String text;
  DateTime created;

  CommentModel({
    required this.id,
    required this.author,
    required this.text,
    required this.created,
  });

  Map<String, dynamic> toJson() => {
        "id": id,
        "author": author,
        "text": text,
        "created": created.toIso8601String(),
      };

  factory CommentModel.fromJson(Map<String, dynamic> j) => CommentModel(
        id: j["id"] as String,
        author: j["author"] as String? ?? '',
        text: j["text"] as String? ?? '',
        created: DateTime.tryParse(j["created"] as String? ?? '') ??
            DateTime.now(),
      );
}
