class FolderModel {
  final String id;
  String name;
  int color;

  FolderModel({
    required this.id,
    required this.name,
    required this.color,
  });

  Map<String, dynamic> toJson() => {"id": id, "name": name, "color": color};

  factory FolderModel.fromJson(Map<String, dynamic> j) => FolderModel(
        id: j["id"] as String,
        name: j["name"] as String,
        color: j["color"] as int,
      );
}
