class TableModel {
  int rows;
  int columns;
  late List<List<String>> cells;

  TableModel({required this.rows, required this.columns}) {
    cells = List.generate(rows, (_) => List.generate(columns, (_) => ""));
  }

  Map<String, dynamic> toJson() =>
      {"rows": rows, "columns": columns, "cells": cells};

  factory TableModel.fromJson(Map<String, dynamic> j) {
    final t = TableModel(rows: j["rows"], columns: j["columns"]);
    final saved = j["cells"] as List;
    for (var r = 0; r < t.rows && r < saved.length; r++) {
      for (var c = 0; c < t.columns && c < (saved[r] as List).length; c++) {
        t.cells[r][c] = saved[r][c] as String;
      }
    }
    return t;
  }
}
