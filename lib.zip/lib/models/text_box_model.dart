import 'package:flutter/material.dart';

class TextBoxModel {
  Offset position;
  Size size;
  String text;

  TextBoxModel({
    required this.position,
    required this.size,
    this.text = "",
  });

  Map<String, dynamic> toJson() => {
        "x": position.dx,
        "y": position.dy,
        "w": size.width,
        "h": size.height,
        "text": text,
      };

  factory TextBoxModel.fromJson(Map<String, dynamic> j) => TextBoxModel(
        position: Offset((j["x"] as num).toDouble(), (j["y"] as num).toDouble()),
        size: Size((j["w"] as num).toDouble(), (j["h"] as num).toDouble()),
        text: j["text"] ?? "",
      );
}
