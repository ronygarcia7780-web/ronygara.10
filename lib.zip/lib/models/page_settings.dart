class PageSettings {
  static const fonts = ["Helvetica", "Times New Roman", "Courier"];

  double marginTop;
  double marginBottom;
  double marginLeft;
  double marginRight;
  double lineSpacing;
  bool pageNumbers;
  bool pageNumberTop; // true = arriba a la derecha (APA)
  String header;
  String footer;
  String font;
  double fontSize;
  double firstLineIndent; // 0 = sin sangría; APA = 36 pt (0.5")
  bool apa; // títulos del mismo tamaño y sin espacio extra entre párrafos

  PageSettings({
    this.marginTop = 72,
    this.marginBottom = 72,
    this.marginLeft = 72,
    this.marginRight = 72,
    this.lineSpacing = 1.15,
    this.pageNumbers = true,
    this.pageNumberTop = false,
    this.header = "",
    this.footer = "",
    this.font = "Helvetica",
    this.fontSize = 12,
    this.firstLineIndent = 0,
    this.apa = false,
  });

  Map<String, dynamic> toJson() => {
        "mt": marginTop,
        "mb": marginBottom,
        "ml": marginLeft,
        "mr": marginRight,
        "ls": lineSpacing,
        "pn": pageNumbers,
        "pt": pageNumberTop,
        "header": header,
        "footer": footer,
        "font": font,
        "fs": fontSize,
        "fi": firstLineIndent,
        "apa": apa,
      };

  factory PageSettings.fromJson(Map<String, dynamic> j) {
    final f = j["font"] as String? ?? "Helvetica";
    return PageSettings(
      marginTop: (j["mt"] as num?)?.toDouble() ?? 72,
      marginBottom: (j["mb"] as num?)?.toDouble() ?? 72,
      marginLeft: (j["ml"] as num?)?.toDouble() ?? 72,
      marginRight: (j["mr"] as num?)?.toDouble() ?? 72,
      lineSpacing: (j["ls"] as num?)?.toDouble() ?? 1.15,
      pageNumbers: j["pn"] as bool? ?? true,
      pageNumberTop: j["pt"] as bool? ?? false,
      header: j["header"] as String? ?? "",
      footer: j["footer"] as String? ?? "",
      font: fonts.contains(f) ? f : "Helvetica",
      fontSize: (j["fs"] as num?)?.toDouble() ?? 12,
      firstLineIndent: (j["fi"] as num?)?.toDouble() ?? 0,
      apa: j["apa"] as bool? ?? false,
    );
  }
}
