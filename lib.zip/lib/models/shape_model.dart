import 'package:flutter/material.dart';

enum ShapeType { rectangle, circle, line }

class ShapeModel {
  ShapeType type;
  Offset position;
  Size size;
  Color color;

  ShapeModel({
    required this.type,
    required this.position,
    required this.size,
    this.color = Colors.blue,
  });

  Map<String, dynamic> toJson() => {
        "type": type.name,
        "x": position.dx,
        "y": position.dy,
        "w": size.width,
        "h": size.height,
        "color": color.toARGB32(),
      };

  factory ShapeModel.fromJson(Map<String, dynamic> j) => ShapeModel(
        type: ShapeType.values.firstWhere(
          (t) => t.name == j["type"],
          orElse: () => ShapeType.rectangle,
        ),
        position: Offset((j["x"] as num).toDouble(), (j["y"] as num).toDouble()),
        size: Size((j["w"] as num).toDouble(), (j["h"] as num).toDouble()),
        color: Color(j["color"] as int),
      );
}
