import 'comment_model.dart';
import 'page_settings.dart';
import 'shape_model.dart';
import 'table_model.dart';
import 'text_box_model.dart';

List<T> _list<T>(dynamic v, T Function(Map<String, dynamic>) f) => v is List
    ? v.map((e) => f(Map<String, dynamic>.from(e as Map))).toList()
    : <T>[];

class ScriptaDocument {
  static const version = 1;

  String id;
  String title;
  List<dynamic> content; // Delta de Quill
  String? folderId;
  PageSettings page;
  List<TableModel> tables;
  List<TextBoxModel> textBoxes;
  List<ShapeModel> shapes;
  List<CommentModel> comments;
  List<String> images; // pendiente: se llenará con las imágenes reales
  String? signature; // PNG en base64
  DateTime created;
  DateTime updated;

  ScriptaDocument({
    required this.id,
    required this.title,
    required this.content,
    required this.page,
    this.folderId,
    this.tables = const [],
    this.textBoxes = const [],
    this.shapes = const [],
    this.comments = const [],
    this.images = const [],
    this.signature,
    required this.created,
    required this.updated,
  });

  Map<String, dynamic> toJson() => {
        "format": "scripta",
        "version": version,
        "id": id,
        "title": title,
        "content": content,
        "folderId": folderId,
        "page": page.toJson(),
        "tables": tables.map((e) => e.toJson()).toList(),
        "textBoxes": textBoxes.map((e) => e.toJson()).toList(),
        "shapes": shapes.map((e) => e.toJson()).toList(),
        "comments": comments.map((e) => e.toJson()).toList(),
        "images": images,
        "signature": signature,
        "created": created.toIso8601String(),
        "updated": updated.toIso8601String(),
      };

  factory ScriptaDocument.fromJson(Map<String, dynamic> j) {
    if (j["format"] != "scripta") {
      throw const FormatException('No es un documento Scripta.');
    }
    final now = DateTime.now();
    return ScriptaDocument(
      id: j["id"] as String,
      title: j["title"] as String? ?? 'Sin título',
      content: j["content"] is List ? j["content"] as List : <dynamic>[],
      folderId: j["folderId"] as String?,
      page: j["page"] is Map
          ? PageSettings.fromJson(Map<String, dynamic>.from(j["page"] as Map))
          : PageSettings(),
      tables: _list(j["tables"], TableModel.fromJson),
      textBoxes: _list(j["textBoxes"], TextBoxModel.fromJson),
      shapes: _list(j["shapes"], ShapeModel.fromJson),
      comments: _list(j["comments"], CommentModel.fromJson),
      images: j["images"] is List ? List<String>.from(j["images"] as List) : [],
      signature: j["signature"] as String?,
      created: DateTime.tryParse(j["created"] as String? ?? '') ?? now,
      updated: DateTime.tryParse(j["updated"] as String? ?? '') ?? now,
    );
  }
}
