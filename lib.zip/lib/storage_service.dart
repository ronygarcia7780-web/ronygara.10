import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import 'document.dart';
import 'models/folder_model.dart';

class StorageService {
  Future<Directory> dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/scripta_docs');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<File> _f(String name) async => File('${(await dir()).path}/$name');

  Future<dynamic> _readJson(String name) async {
    final f = await _f(name);
    if (!await f.exists()) return null;
    try {
      return jsonDecode(await f.readAsString());
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeJson(String name, Object data) async {
    final f = await _f(name);
    await f.writeAsString(jsonEncode(data));
  }

  // ---- Documentos (índice) ----
  Future<List<DocumentModel>> load() async {
    final d = await _readJson('index.json');
    if (d is! List) return [];
    try {
      return d
          .map((e) => DocumentModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> save(List<DocumentModel> docs) =>
      _writeJson('index.json', docs.map((e) => e.toJson()).toList());

  Future<void> touch(DocumentModel doc) async {
    final docs = await load();
    final i = docs.indexWhere((d) => d.id == doc.id);
    if (i == -1) return;
    docs[i].updated = doc.updated;
    await save(docs);
  }

  // ---- Contenido y objetos ----
  Future<List<dynamic>?> loadContent(String id) async {
    final d = await _readJson('$id.json');
    return d is List ? d : null;
  }

  Future<void> saveContent(String id, List<dynamic> delta) =>
      _writeJson('$id.json', delta);

  Future<Map<String, dynamic>?> loadObjects(String id) async {
    final d = await _readJson('${id}_objects.json');
    return d is Map<String, dynamic> ? d : null;
  }

  Future<void> saveObjects(String id, Map<String, dynamic> data) =>
      _writeJson('${id}_objects.json', data);

  // ---- Carpetas ----
  Future<List<FolderModel>> loadFolders() async {
    final d = await _readJson('folders.json');
    if (d is! List) return [];
    try {
      return d
          .map((e) => FolderModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveFolders(List<FolderModel> folders) =>
      _writeJson('folders.json', folders.map((e) => e.toJson()).toList());

  // ---- Firma (PNG) ----
  Future<Uint8List?> loadSignature(String id) async {
    final f = await _f('${id}_signature.png');
    if (!await f.exists()) return null;
    return f.readAsBytes();
  }

  Future<void> saveSignature(String id, Uint8List bytes) async {
    final f = await _f('${id}_signature.png');
    await f.writeAsBytes(bytes);
  }

  Future<void> deleteSignature(String id) async {
    final f = await _f('${id}_signature.png');
    if (await f.exists()) await f.delete();
  }

  // ---- Índice de búsqueda ----
  Future<Map<String, dynamic>> loadSearchIndex() async {
    final d = await _readJson('search_index.json');
    return d is Map<String, dynamic> ? d : <String, dynamic>{};
  }

  Future<void> saveSearchIndex(Map<String, dynamic> index) =>
      _writeJson('search_index.json', index);

  // ---- Borrar los archivos de un documento ----
  Future<void> deleteFiles(String id) async {
    for (final name in ['$id.json', '${id}_objects.json', '${id}_signature.png']) {
      final f = await _f(name);
      if (await f.exists()) await f.delete();
    }
  }
}
