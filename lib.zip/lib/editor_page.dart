import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart';

import 'document.dart';
import 'storage_service.dart';
import 'editor/autosave_service.dart';
import 'editor/editor_toolbar.dart';
import 'editor/word_counter.dart';
import 'models/page_settings.dart';
import 'models/shape_model.dart';
import 'models/text_box_model.dart';
import 'services/apa_service.dart';
import 'services/pdf_service.dart';
import 'services/requirement_checker.dart';
import 'signature/signature_pad.dart';
import 'widgets/object_layer.dart';
import 'widgets/page_settings_sheet.dart';

class EditorPage extends StatefulWidget {
  final DocumentModel doc;
  final StorageService storage;

  const EditorPage({super.key, required this.doc, required this.storage});

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  late QuillController _controller;
  final _autoSave = AutoSaveService();
  final _pdf = PdfService();
  StreamSubscription? _sub;

  final _textBoxes = <TextBoxModel>[];
  final _shapes = <ShapeModel>[];
  PageSettings _page = PageSettings();
  Uint8List? _signature;

  bool _ready = false;
  bool _dirty = false;
  int _words = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await widget.storage.loadContent(widget.doc.id);
    final document = (data != null && data.isNotEmpty)
        ? Document.fromJson(data)
        : Document();

    final obj = await widget.storage.loadObjects(widget.doc.id);
    if (obj != null) {
      _textBoxes.addAll(((obj["textBoxes"] ?? []) as List)
          .map((e) => TextBoxModel.fromJson(e as Map<String, dynamic>)));
      _shapes.addAll(((obj["shapes"] ?? []) as List)
          .map((e) => ShapeModel.fromJson(e as Map<String, dynamic>)));
      if (obj["page"] != null) {
        _page = PageSettings.fromJson(obj["page"] as Map<String, dynamic>);
      }
    }

    _signature = await widget.storage.loadSignature(widget.doc.id);

    _controller = QuillController(
      document: document,
      selection: const TextSelection.collapsed(offset: 0),
    );
    _words = countWords(document.toPlainText());

    _sub = _controller.document.changes.listen((_) {
      _dirty = true;
      if (!mounted) return;
      setState(() => _words = countWords(_controller.document.toPlainText()));
    });

    _autoSave.start(_save);

    if (!mounted) return;
    setState(() => _ready = true);
  }

  void _markDirty() => _dirty = true;

  Future<void> _save() async {
    if (!_ready || !_dirty) return;
    _dirty = false;
    final content = _controller.document.toDelta().toJson();
    final objects = {
      "textBoxes": _textBoxes.map((e) => e.toJson()).toList(),
      "shapes": _shapes.map((e) => e.toJson()).toList(),
      "page": _page.toJson(),
    };
    widget.doc.updated = DateTime.now();
    await widget.storage.saveContent(widget.doc.id, content);
    await widget.storage.saveObjects(widget.doc.id, objects);
    await widget.storage.touch(widget.doc);
  }

  Future<void> _exportPdf() async {
    try {
      await _pdf.export(
        document: _controller.document,
        settings: _page,
        title: widget.doc.title,
        signature: _signature,
      );
    } catch (e) {
      _soon("No se pudo crear el PDF: $e");
    }
  }

  // ---------- Menú ----------
  void _onMenu(String v) {
    switch (v) {
      case 'page':
        _openPageSettings();
      case 'apa':
        _applyApa();
      case 'check':
        _checkRequirements();
      case 'sign':
        _sign();
      case 'unsign':
        _unsign();
    }
  }

  Future<void> _openPageSettings() async {
    final changed = await showPageSettingsSheet(context, _page);
    if (changed) {
      _markDirty();
      if (mounted) setState(() {});
    }
  }

  void _applyApa() {
    APAService().apply(_page);
    _markDirty();
    setState(() {});
    _soon("Formato APA 7 aplicado. Se ve en el PDF, no en la pantalla.");
  }

  void _checkRequirements() {
    final issues = RequirementChecker.checkApa(_page, words: _words);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Requisitos APA 7'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (issues.isEmpty)
                const Text('La configuración de página cumple lo revisado.')
              else
                for (final i in issues)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.warning_amber, size: 18),
                        const SizedBox(width: 8),
                        Expanded(child: Text(i)),
                      ],
                    ),
                  ),
              const SizedBox(height: 8),
              Text('Palabras: $_words'),
              const SizedBox(height: 4),
              const Text(
                'Solo se revisa la configuración de página, no el contenido.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  Future<void> _sign() async {
    final png = await showSignatureDialog(context);
    if (png == null || !mounted) return;
    await widget.storage.saveSignature(widget.doc.id, png);
    if (!mounted) return;
    setState(() => _signature = png);
    _soon('Firma guardada. Aparecerá al final del PDF.');
  }

  Future<void> _unsign() async {
    await widget.storage.deleteSignature(widget.doc.id);
    if (!mounted) return;
    setState(() => _signature = null);
  }

  // ---------- Objetos ----------
  void _addTextBox() {
    setState(() => _textBoxes.add(TextBoxModel(
          position: const Offset(40, 80),
          size: const Size(200, 100),
        )));
    _markDirty();
  }

  void _deleteTextBox(TextBoxModel m) {
    setState(() => _textBoxes.remove(m));
    _markDirty();
  }

  void _addShape() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.crop_square),
              title: const Text("Rectángulo"),
              onTap: () => _pickShape(ShapeType.rectangle),
            ),
            ListTile(
              leading: const Icon(Icons.circle_outlined),
              title: const Text("Círculo"),
              onTap: () => _pickShape(ShapeType.circle),
            ),
            ListTile(
              leading: const Icon(Icons.horizontal_rule),
              title: const Text("Línea"),
              onTap: () => _pickShape(ShapeType.line),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text("Borrar todas las formas"),
              onTap: () {
                Navigator.pop(context);
                setState(() => _shapes.clear());
                _markDirty();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _pickShape(ShapeType type) {
    Navigator.pop(context);
    setState(() => _shapes.add(ShapeModel(
          type: type,
          position: const Offset(60, 200),
          size: const Size(140, 90),
        )));
    _markDirty();
  }

  void _soon(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    _autoSave.stop();
    if (_ready) {
      _save();
      _sub?.cancel();
      _controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.doc.title)),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.doc.title),
        actions: [
          Center(child: Text("$_words palabras")),
          IconButton(
            tooltip: "Exportar PDF",
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: _exportPdf,
          ),
          PopupMenuButton<String>(
            onSelected: _onMenu,
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'page', child: Text('Configurar página')),
              const PopupMenuItem(value: 'apa', child: Text('Aplicar formato APA 7')),
              const PopupMenuItem(value: 'check', child: Text('Revisar requisitos APA')),
              const PopupMenuItem(value: 'sign', child: Text('Firmar documento')),
              if (_signature != null)
                const PopupMenuItem(value: 'unsign', child: Text('Quitar firma')),
            ],
          ),
        ],
      ),
      bottomNavigationBar: BottomEditorToolbar(
        onImage: () => _soon("Imágenes: siguiente paso."),
        onTable: () => _soon("Tablas: se integran como embed de Quill."),
        onSearch: () => _soon("Buscar en el documento: próxima versión."),
        onTextBox: _addTextBox,
        onShape: _addShape,
      ),
      body: Column(
        children: [
          QuillSimpleToolbar(controller: _controller),
          Expanded(
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: QuillEditor.basic(controller: _controller),
                ),
                ObjectLayer(
                  textBoxes: _textBoxes,
                  shapes: _shapes,
                  onChanged: _markDirty,
                  onDeleteTextBox: _deleteTextBox,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
