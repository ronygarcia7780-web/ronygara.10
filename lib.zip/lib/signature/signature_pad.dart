import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class SignatureController extends ChangeNotifier {
  final List<List<Offset>> strokes = [];

  bool get isEmpty => strokes.isEmpty;

  void start(Offset p) {
    strokes.add([p]);
    notifyListeners();
  }

  void add(Offset p) {
    if (strokes.isEmpty) return;
    strokes.last.add(p);
    notifyListeners();
  }

  void undo() {
    if (strokes.isEmpty) return;
    strokes.removeLast();
    notifyListeners();
  }

  void clear() {
    strokes.clear();
    notifyListeners();
  }

  /// PNG recortado a la firma, tinta negra sobre fondo transparente.
  Future<Uint8List?> toPng() async {
    final pts = strokes.where((s) => s.isNotEmpty).toList();
    if (pts.isEmpty) return null;

    var l = double.infinity, t = double.infinity;
    var r = -double.infinity, b = -double.infinity;
    for (final s in pts) {
      for (final p in s) {
        if (p.dx < l) l = p.dx;
        if (p.dy < t) t = p.dy;
        if (p.dx > r) r = p.dx;
        if (p.dy > b) b = p.dy;
      }
    }

    const pad = 8.0;
    const scale = 3.0;
    final w = (r - l) + pad * 2;
    final h = (b - t) + pad * 2;

    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    canvas.scale(scale);
    canvas.translate(-l + pad, -t + pad);
    _paintStrokes(canvas, pts, Colors.black);

    final img = await rec
        .endRecording()
        .toImage((w * scale).ceil(), (h * scale).ceil());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    return data?.buffer.asUint8List();
  }
}

void _paintStrokes(Canvas canvas, List<List<Offset>> strokes, Color color) {
  final line = Paint()
    ..color = color
    ..strokeWidth = 3
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..style = PaintingStyle.stroke;
  final dot = Paint()..color = color;

  for (final s in strokes) {
    if (s.isEmpty) continue;
    if (s.length == 1) {
      canvas.drawCircle(s.first, 1.5, dot);
      continue;
    }
    final path = Path()..moveTo(s.first.dx, s.first.dy);
    for (final p in s.skip(1)) {
      path.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(path, line);
  }
}

class SignaturePad extends StatelessWidget {
  final SignatureController controller;
  final double height;

  const SignaturePad({
    super.key,
    required this.controller,
    this.height = 220,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: GestureDetector(
          onPanStart: (d) => controller.start(d.localPosition),
          onPanUpdate: (d) => controller.add(d.localPosition),
          child: ListenableBuilder(
            listenable: controller,
            builder: (_, __) => CustomPaint(
              painter: _SignaturePainter(controller.strokes),
              size: Size.infinite,
            ),
          ),
        ),
      ),
    );
  }
}

class _SignaturePainter extends CustomPainter {
  final List<List<Offset>> strokes;
  _SignaturePainter(this.strokes);

  @override
  void paint(Canvas canvas, Size size) =>
      _paintStrokes(canvas, strokes, Colors.black);

  @override
  bool shouldRepaint(_SignaturePainter old) => true;
}

/// Abre el diálogo de firma. Devuelve el PNG o null si cancela.
Future<Uint8List?> showSignatureDialog(BuildContext context) async {
  final c = SignatureController();
  final png = await showDialog<Uint8List>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Firma con el dedo'),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SignaturePad(controller: c),
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton.icon(
                  onPressed: c.undo,
                  icon: const Icon(Icons.undo),
                  label: const Text('Deshacer'),
                ),
                TextButton.icon(
                  onPressed: c.clear,
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Borrar'),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: () async {
            final bytes = await c.toPng();
            if (bytes != null && ctx.mounted) Navigator.pop(ctx, bytes);
          },
          child: const Text('Guardar'),
        ),
      ],
    ),
  );
  return png;
}
