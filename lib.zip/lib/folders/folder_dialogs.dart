import 'package:flutter/material.dart';
import '../models/folder_model.dart';

const folderColors = [
  Colors.blue,
  Colors.red,
  Colors.green,
  Colors.orange,
  Colors.purple,
  Colors.teal,
];

/// Devuelve el texto escrito, o null si cancela o queda vacío.
Future<String?> askText(
  BuildContext context,
  String title, {
  String initial = '',
}) async {
  final c = TextEditingController(text: initial);
  final r = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        autofocus: true,
        decoration: const InputDecoration(labelText: 'Nombre'),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, c.text.trim()),
          child: const Text('Aceptar'),
        ),
      ],
    ),
  );
  return (r == null || r.isEmpty) ? null : r;
}

/// Crea o edita una carpeta. Devuelve null si cancela.
Future<FolderModel?> askFolder(
  BuildContext context, {
  FolderModel? current,
}) {
  final name = TextEditingController(text: current?.name ?? '');
  var color = current?.color ?? folderColors.first.toARGB32();

  return showDialog<FolderModel>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(current == null ? 'Nueva carpeta' : 'Editar carpeta'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: name,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Nombre'),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: [
                for (final c in folderColors)
                  GestureDetector(
                    onTap: () => set(() => color = c.toARGB32()),
                    child: CircleAvatar(
                      backgroundColor: c,
                      radius: 14,
                      child: color == c.toARGB32()
                          ? const Icon(Icons.check,
                              size: 16, color: Colors.white)
                          : null,
                    ),
                  ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              final n = name.text.trim();
              if (n.isEmpty) return;
              Navigator.pop(
                ctx,
                FolderModel(
                  id: current?.id ??
                      DateTime.now().microsecondsSinceEpoch.toString(),
                  name: n,
                  color: color,
                ),
              );
            },
            child: const Text('Guardar'),
          ),
        ],
      ),
    ),
  );
}

/// Devuelve el id de la carpeta, '' si elige "Sin carpeta", null si cancela.
Future<String?> pickFolder(BuildContext context, List<FolderModel> folders) {
  return showModalBottomSheet<String>(
    context: context,
    builder: (ctx) => SafeArea(
      child: ListView(
        shrinkWrap: true,
        children: [
          ListTile(
            leading: const Icon(Icons.folder_off_outlined),
            title: const Text('Sin carpeta'),
            onTap: () => Navigator.pop(ctx, ''),
          ),
          for (final f in folders)
            ListTile(
              leading: Icon(Icons.folder, color: Color(f.color)),
              title: Text(f.name),
              onTap: () => Navigator.pop(ctx, f.id),
            ),
        ],
      ),
    ),
  );
}

Future<bool> confirm(BuildContext context, String title, String message) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('Aceptar'),
        ),
      ],
    ),
  );
  return r == true;
}
