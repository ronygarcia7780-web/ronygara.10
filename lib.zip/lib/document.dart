class DocumentModel {
  final String id;
  String title;
  DateTime updated;
  String? folderId;

  DocumentModel({
    required this.id,
    required this.title,
    required this.updated,
    this.folderId,
  });

  factory DocumentModel.create(String title, {String? folderId}) =>
      DocumentModel(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title,
        updated: DateTime.now(),
        folderId: folderId,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "updated": updated.toIso8601String(),
        "folderId": folderId,
      };

  factory DocumentModel.fromJson(Map<String, dynamic> json) =>
      DocumentModel(
        id: json["id"],
        title: json["title"],
        updated: DateTime.parse(json["updated"]),
        folderId: json["folderId"] as String?,
      );
}
